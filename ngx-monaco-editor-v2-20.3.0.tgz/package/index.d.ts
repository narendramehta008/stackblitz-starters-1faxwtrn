import { ControlValueAccessor } from '@angular/forms';
import * as i0 from '@angular/core';
import { InjectionToken, AfterViewInit, OnDestroy, ElementRef, EventEmitter, ModuleWithProviders } from '@angular/core';
import { Subscription } from 'rxjs';
import * as i1 from '@angular/common';

declare const NGX_MONACO_EDITOR_CONFIG: InjectionToken<unknown>;
interface NgxMonacoEditorConfig {
    baseUrl?: string;
    requireConfig?: {
        [key: string]: any;
    };
    defaultOptions?: {
        [key: string]: any;
    };
    monacoRequire?: Function;
    onMonacoLoad?: Function;
}

declare abstract class BaseEditor implements AfterViewInit, OnDestroy {
    config: NgxMonacoEditorConfig;
    set insideNg(insideNg: boolean);
    get insideNg(): boolean;
    _editorContainer: ElementRef;
    onInit: EventEmitter<any>;
    protected _editor: any;
    protected _options: any;
    protected _windowResizeSubscription: Subscription;
    private _insideNg;
    ngAfterViewInit(): void;
    protected abstract initMonaco(options: any, insideNg: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseEditor, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseEditor, "ng-component", never, { "insideNg": { "alias": "insideNg"; "required": false; }; }, { "onInit": "onInit"; }, never, never, false, never>;
}

interface DiffEditorModel {
    code: string;
    language: string;
}
interface NgxEditorModel {
    value: string;
    language?: string;
    uri?: any;
}

declare class EditorComponent extends BaseEditor implements ControlValueAccessor {
    private zone;
    private _value;
    propagateChange: (_: any) => void;
    onTouched: () => void;
    set options(options: any);
    get options(): any;
    set model(model: NgxEditorModel);
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(disabled: boolean): void;
    protected initMonaco(options: any, insideNg: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditorComponent, "ngx-monaco-editor", never, { "options": { "alias": "options"; "required": false; }; "model": { "alias": "model"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DiffEditorComponent extends BaseEditor {
    private zone;
    _originalModel: DiffEditorModel;
    _modifiedModel: DiffEditorModel;
    set options(options: any);
    get options(): any;
    set originalModel(model: DiffEditorModel);
    set modifiedModel(model: DiffEditorModel);
    protected initMonaco(options: any, insideNg: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiffEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiffEditorComponent, "ngx-monaco-diff-editor", never, { "options": { "alias": "options"; "required": false; }; "originalModel": { "alias": "originalModel"; "required": false; }; "modifiedModel": { "alias": "modifiedModel"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MonacoEditorModule {
    static forRoot(config?: NgxMonacoEditorConfig): ModuleWithProviders<MonacoEditorModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonacoEditorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MonacoEditorModule, never, [typeof i1.CommonModule, typeof EditorComponent, typeof DiffEditorComponent], [typeof EditorComponent, typeof DiffEditorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MonacoEditorModule>;
}
declare function provideMonacoEditor(config?: NgxMonacoEditorConfig): i0.EnvironmentProviders;

export { DiffEditorComponent, EditorComponent, MonacoEditorModule, NGX_MONACO_EDITOR_CONFIG, provideMonacoEditor };
export type { DiffEditorModel, NgxEditorModel, NgxMonacoEditorConfig };
